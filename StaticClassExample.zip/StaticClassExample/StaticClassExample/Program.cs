﻿namespace StaticClassExample
{
    internal class Program
    {
        //Static Class and Member decleration
        //public static class Calculator
        //{
        //    private static int _resultStorage = 0;

        //    public static string Type = "Arithmetic";

        //    public static int Sum(int num1, int num2)
        //    {
        //        return num1 + num2;
        //    }

        //    public static void Store(int result)
        //    {
        //        _resultStorage = result;
        //    }
        //}

        //Shared Static Fields
        //public class StopWatch
        //{
        //    public static int NoOfInstances = 0;

        //    // instance constructor
        //    public StopWatch()
        //    {
        //        StopWatch.NoOfInstances++;
        //    }
        //}

        //public class DemoStatic
        //{
        //    public static int counter = 0;
        //    public string name = "Demo Program";

        //   public static void Display(string text)
        //    {
        //        Console.WriteLine(text);
        //    }
        //    public void SetRootFolder(string path) { }
        //}

        //Static Constructors
        public class StopWatch
        {
            // static constructor
            static StopWatch()
            {
                Console.WriteLine("Static constructor called");
            }

            // instance constructor
            public StopWatch()
            {
                Console.WriteLine("Instance constructor called");
            }

            // static method
            public static void DisplayInfo()
            {
                Console.WriteLine("DisplayInfo called");
            }

            // instance method
            public void Start() { }

            // instance method
            public void Stop() { }
        }



        static void Main(string[] args)
        {
            //Static Class and Member calling in Main Method
            //var result = Calculator.Sum(10, 25); // calling static method
            //Calculator.Store(result);
            //Console.WriteLine(result);
            //var calcType = Calculator.Type; // accessing static variable
            //Calculator.Type = "Scientific"; // assign value to static variable
            //Console.WriteLine(calcType);

            //StopWatch sw1 = new StopWatch();
            //StopWatch sw2 = new StopWatch();
            //Console.WriteLine(StopWatch.NoOfInstances); //2 

            //StopWatch sw3 = new StopWatch();
            //StopWatch sw4 = new StopWatch();
            //Console.WriteLine(StopWatch.NoOfInstances);//4

            //Static Method
            //DemoStatic.counter++; // can access static fields
            //DemoStatic.Display("Hello World!"); // can call static methods

            //DemoStatic objdemo = new DemoStatic();
            //objdemo.name = "New Demo Program"; //Error: cannot access non-static members
            //objdemo.SetRootFolder("C:\\MyProgram"); //Error: cannot call non-static method

            StopWatch.DisplayInfo(); // static constructor called here
            StopWatch.DisplayInfo(); // none of the constructors called here
        }

    }
}
