﻿namespace AnonymousType
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // int a = 10;
            //var student = new { Id = 1, FirstName = "James", LastName = "Bond" };
            //Console.WriteLine(student.Id); //output: 1
            //Console.WriteLine(student.FirstName); //output: James
            //Console.WriteLine(student.LastName); //output: Bond

            //student.Id = 3;
            //student.FirstName = "hhhh";


            // Nested AnonymousType
            //var student = new
            //{
            //    Id = 1,
            //    FirstName = "James",
            //    LastName = "Bond",
            //    Address = new { Id = 1, City = "London", Country = "UK" }
            //};

            //Console.WriteLine(student.Id); //output: 1
            //Console.WriteLine(student.FirstName); //output: James
            //Console.WriteLine(student.LastName); //output: Bond
            //Console.WriteLine(student.Address.Country); //output: UK

            //var students = new[] {
            //new { Id = 1, FirstName = "James", LastName = "Bond" },
            //new { Id = 2, FirstName = "Steve", LastName = "Jobs" },
            //new { Id = 3, FirstName = "Bill", LastName = "Gates" }
            // };


            //for (int i = 0; i < students.Length; i++)
            //{
            //    Console.WriteLine(students[i].Id);
            //    Console.WriteLine(students[i].FirstName);
            //    Console.WriteLine(students[i].LastName);

            //}

            // Internal Name of an Anonymous Type
            var student = new { Id = 1, FirstName = "James", LastName = "Bond" };
            Console.WriteLine(student.GetType().ToString());
        }
    }
}
