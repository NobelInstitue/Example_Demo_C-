﻿
#region Interface
//Circle objcircle = new Circle();
//objcircle.CalculateArea();
//objcircle.CalculatePerimerter();

////Rectangle objrect=new Rectangle();
////objrect.CalculateArea();
////objrect.CalculatePerimerter();

//public class Circle : IShapeArea, IShapePerimeter
//{
//    public void CalculateArea()
//    {
//        int radius = 5;
//        double area = Math.PI * radius * radius;
//        Console.WriteLine($"Area of Circle is {area}");
//    }

//    public void CalculatePerimerter()
//    {
//        int radius = 5;
//        double Perimeter = 2 * Math.PI * radius;
//        Console.WriteLine($"Perimeter of Circle is {Perimeter}");
//    }
//}

////public class Rectangle : IShape
////{
////    public void CalculateArea()
////    {
////        int length = 15;
////        int width = 5;
////        double area = length * width;
////        Console.WriteLine($"Area of Rectangle is {area}");
////    }

////    public void CalculatePerimerter()
////    {
////        int length = 15;
////        int width = 5;
////        double Perimeter = 2 * (length + width);
////        Console.WriteLine($"Perimeter of Rectangle {Perimeter}");
////    }
////}


//public interface IShapeArea
//{
//    public int age { get; set; }
//    //int age;
  
//    public void CalculateArea();
//}

//public interface IShapePerimeter
//{
//    public void CalculatePerimerter();
//}
#endregion

#region Abstract Class

Shape objCircle = new Circle();
objCircle.CalculateArea();
objCircle.CalculatePerimeter();

public abstract class Shape
{
    public int radius { get; set; }
    private int age;
    public abstract void CalculateArea();
  
    public void CalculatePerimeter()
    {      
        int radius = 5;
        double Perimeter = 2 * Math.PI * radius;
         Console.WriteLine($"Perimeter of Circle is {Perimeter}");
    }

}

public class Circle :Shape{
   
    public override void CalculateArea()
    {
        int radius = 5;
               double area = Math.PI * radius * radius;
            Console.WriteLine($"Area of Circle is {area}");
    }
}


#endregion