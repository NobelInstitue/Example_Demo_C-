﻿

Car objcar = new Car();

objcar.Make = "Honda";
objcar.Model = "Jazz";
//objcar.YearRegisterd = 2019;
objcar.nofdoor = 4;
((Vehicle)objcar).Start();
objcar.Start();
objcar.park();
objcar.Stop();




Motorcycle objmt = new Motorcycle();
objmt.Make = "Honda";
objmt.Model = "CBZ";
//objmt.YearRegisterd = 2022;
objmt.Start();
objmt.Wheelie();
objmt.Stop();


public class Vehicle
{
    public string Make { get; set; }
    public string Model { get; set; }
    protected int YearRegisterd { get; set; }


    public void Start()
    {
        YearRegisterd = 22;
        Console.WriteLine("Vehicle is started");
    }
    public void Stop()
    {
        Console.WriteLine("Vehicle is stopped");
    }
}


public class Car: Vehicle
{  
    public int nofdoor { get; set; }

    public new void Start()
    {
        YearRegisterd = 2020;
        //base.Start();
        Console.WriteLine("car is started");
    }
    public void park()
    {
        Console.WriteLine("car is parked");
    }

}

public class Motorcycle : Car
{       
    
    public void Wheelie()
    {
        YearRegisterd = 2202;
        Console.WriteLine("Moterocycle is Wheelie");
    }

}