﻿

Employee emp = new Employee();
emp.id = 99;
emp.name = "Nobel";
emp.salary = 16000;
Console.WriteLine($"Emp id {emp.id}  emp name {emp.name} and emp salary {emp.salary}");

public class Employee
{


    public int id { get; set; }
    public string name { get; set; }
    public int salary { get; set; }

    

    //public int _id;
    //public string _name;
    //public int _salary;

    //public int id
    //{
    //    set
    //    {
    //        if (value > 0)
    //        {
    //            _id = value;
    //        }
    //        else
    //        {
    //            throw new Exception("Id can not be negative");
    //        }
    //    }
    //    get
    //    {
    //        return _id;
    //    }
    //}

    //public string name
    //{
    //    set
    //    {
    //        if (string.IsNullOrWhiteSpace(value))
    //        {
    //            throw new Exception("name can not be null or empty space");
    //        }
    //        else
    //        {
    //            _name = value;
    //        }
    //    }
    //    get
    //    {
    //        return _name;
    //    }
    //}

    //public int salary
    //{
    //    set
    //    {
    //        _salary = IncrementedSalary(value);
    //    }
    //    get
    //    {
    //        return _salary;
    //    }
    //}

    //public int IncrementedSalary(int newvalue)
    //{

    //    //_salary = 10000;
    //   return _salary = newvalue + 1000;
    //}



}