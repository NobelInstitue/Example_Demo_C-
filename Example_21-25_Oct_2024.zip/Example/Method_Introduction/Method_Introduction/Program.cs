﻿//namespace Method_Introduction
//{
//    internal class Program
//    {
//        static void Main(string[] args)
//        {
//            Program pgmobj=new Program();
//            Console.WriteLine("Please Enter Firstname");
//            string firstname=Cz
//            pgmobj.PrintString(FirstName,"Solutions");
            
//        }

//        public void PrintString(string Fname,string Lname)
//        {
//            Console.WriteLine($"Full name is {Fname} {Lname}");           
//        }
//    }
//}
