﻿
////string name = "Nobel Solutions";

//void Methodone()
//{
//  string  name = "New name";
//    Console.WriteLine(name);
//}

//void MethodTwo()
//{
	
//	for (int i = 0; i < 10; i++)
//	{
//        Console.WriteLine(i);
//	}
//    i = 15;
//}

//void Employee(string name,string Des="Contractor",int salary=10000)
//{
//    Console.WriteLine($"Employee Name is {name}");
//    Console.WriteLine($"Employee Designation is {Des}");
//    Console.WriteLine($"Employee salary is {salary}");
//}



//Employee(Des:"Senior", salary: 15000,name: "Komal");
