﻿


public  class Employee
{
    string firstname = "Nobel";
    string lastname = "solutions";

    public static void printName()
    {
        Console.WriteLine($"This is Full name {firstname} {lastname}");
    }
}