﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Program progmobj = new Program();
            progmobj.PrintName();
        }

        public void PrintName()
        {
            Console.WriteLine( "This is a introduction of Method");
        }

    }
}
