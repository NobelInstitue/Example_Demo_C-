﻿
//Method Overridding

//Employee[] emps = new Employee[4];
//emps[0] = new Employee()
//{
//    firstname = "Normal",
//    lastname = "Employee"
//};

//emps[1] = new PartTimeEmployee()
//{
//    firstname = "Parttime",
//    lastname = "Employee"
//};

//emps[2] = new FullTimeEmployee()
//{
//    firstname = "FullTime",
//    lastname = "Employee"
//};
//emps[3] = new ContractEmployee()
//{
//    firstname = "Contract",
//    lastname = "Employee"
//};

//foreach (Employee emp in emps)
//{
//    emp.PrintName();
//}



//public class Employee
//{
//    public string firstname { get; set; }
//    public string lastname { get; set; }
//    public virtual void PrintName()
//    {
//        Console.WriteLine($"The name of employeee is {firstname} {lastname}");
//    }

//}

//public class PartTimeEmployee:Employee
//{
//    public override void PrintName()
//    {
//       Console.WriteLine($"The name of employeee is {firstname} {lastname}-PartTime Employee");
//    }
//}
//public class FullTimeEmployee:Employee
//{
//    public override void PrintName()
//    {
//        Console.WriteLine($"The name of employeee is {firstname} {lastname}-FullTime Employee");
//    }
//}
//public class ContractEmployee: Employee
//{
//    public override void PrintName()
//    {
//        Console.WriteLine($"The name of employeee is {firstname} {lastname}-Constract Employee");
//    }
//}


