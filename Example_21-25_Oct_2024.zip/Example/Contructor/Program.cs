﻿


//Employee emp = new Employee()
//{
//    emp.firstname = "Komal",
//    emp.lastname = "Patil"
//};

//Employee emp2 = new Employee();
//emp2.firstname="sssd";
//emp2.lastname = "fghf";
//emp2.printDept();
////emp.printname();

//public class Employee
//{   

//    //public Employeeone(string fname,string lname) {
//    private string firstname = "Yash";
//    private  string lastname = "Jadhav";

//    Department();
//    //    Console.WriteLine(fname+"" + lname);
//    //}

//    //public void printname()
//    //{
//    //    Console.WriteLine($"Firsname {firstname} lastname {lastname}");
//    //}

//    public void Department()
//    {
//        Console.Write("This is new dept");
//    }
   
//}





