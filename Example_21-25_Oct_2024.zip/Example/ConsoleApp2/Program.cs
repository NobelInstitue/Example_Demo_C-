﻿namespace ConsoleApp2
{
    internal class Program
    {
       


        public static void printname(string fname,string lname)
        {
            
            Console.WriteLine($"This is fullname {fname} {lname} ");
        }





        static void Main(string[] args)
        {
            string firstname = "Nobel";
            string lastname = "solution";
            Program.printname(firstname, lastname);
        }
    }
}
