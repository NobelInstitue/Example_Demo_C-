﻿
Employee.PrintName();


public class Employee
{
   

    public static void PrintName()
    {
       // 
       public string firstname = "Nobel";
      public string lastname = "Solutions";
    Console.WriteLine($"This is Full Name {Employee.firstname} {Employee.lastname} ");
     }
}