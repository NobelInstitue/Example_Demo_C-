﻿namespace Employee
{
    public class Class1
    {

    }
}
