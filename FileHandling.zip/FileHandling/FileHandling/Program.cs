﻿using System.Text;
using Microsoft.Office.Interop.Excel;


namespace FileHandling
{
    internal class Program
    {
        static void Main(string[] args)
        {

            string Filepath = @"D:\ExampleC#\File\NewFile.txt";

            //FileStream fs = new FileStream(Filepath, FileMode.Append);

            //byte[] data = Encoding.Default.GetBytes("This is test data ");

            //fs.Write(data, 0, data.Length);

            //fs.Close();
            //Console.WriteLine("File Create Successfully");
            //Console.ReadLine();


            //FileStream fs=new FileStream(Filepath, FileMode.Append, FileAccess.Write);
            //StreamWriter sw=new StreamWriter(fs);
            //Console.WriteLine("Enter the text you want to write into the file");
            //string str = Console.ReadLine();
            //sw.WriteLine(str);
            //sw.Flush();
            //sw.Close();
            //fs.Close();
            //Console.WriteLine("File Create with your Data");


            FileStream fs=new FileStream(Filepath,FileMode.Open, FileAccess.Read);
            string data;
            using (StreamReader sr = new StreamReader(fs)) { 
                data = sr.ReadToEnd();
                sr.Close();
            }
            Console.WriteLine(data);
            Console.ReadLine();

            string dFilePath = @"D:\\ExampleC#\NewFile.txt";

            //File.Copy(Filepath, dFilePath);
            if (File.Exists(Filepath))
            {
                File.Move(Filepath, dFilePath);
            }
            Console.WriteLine("File Copied successfully");
            Console.ReadKey();


            

        }
    }
}
