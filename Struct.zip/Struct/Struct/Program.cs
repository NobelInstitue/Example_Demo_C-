﻿namespace Struct
{
    internal class Program
    {
        //struct Coordinate
        //{
        //    public string x;
        //    public int y;

        //}
        //struct Coordinate
        //{
        //    public string x;
        //    public int y;

        //    public Coordinate(string x, int y)
        //    {
        //        this.x = x;
        //        this.y = y;
        //    }
        //}

        //struct Coordinate
        //{
        //    public int x { get; set; }
        //    public int y { get; set; }

        //    public void SetOrigin()
        //    {
        //        this.x = 4;
        //        this.y = 0;

        //    }
        //}
        struct Coordinate
        {
            public int x;
            public int y;

            public Coordinate(int x, int y)
            {
                this.x = x;
                this.y = y;
            }
            public static Coordinate GetOrigin()
            {
                return new Coordinate();
            }
        }
        static void Main(string[] args)
        {
            // Coordinate obj=new Coordinate();


            //Coordinate point;
            //point.x = "Hi";
            //point.y = 7;
            //Console.WriteLine(point.x); //output: 0  
            //Console.WriteLine(point.y); //output: 0 

            //Coordinate point = new Coordinate("Hello", 20);

            //Console.WriteLine(point.x); //output: 10  
            //Console.WriteLine(point.y); //output: 20

            //Coordinate point=new Coordinate();
            //point.SetOrigin();
            ////point.x = 4;
            //Console.WriteLine(point.x); //output: 0  
            //Console.WriteLine(point.y); //output: 0


            Coordinate point = Coordinate.GetOrigin();

            Console.WriteLine(point.x); //output: 0  
            Console.WriteLine(point.y); //output: 0 


        }
    }
}
