﻿namespace ExceptionHandling
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program();
            p.dividebyzero();
        }

        public void dividebyzero()
        {
            try
            {
                int a = 9;
                int b = 1;
               
                if (b <= 1)
                {
                    throw new Exception("b is less than zero");
                }
                int c = a / b;
                Console.WriteLine(c);
            }
            //catch (DivideByZeroException e)
            //{
            //    Console.WriteLine(e.Message);

            //}
            //catch(Exception e)
            //{
            //    Console.WriteLine("Exception");
            //}
            finally
            {
                Console.WriteLine("This exception");
            }
        }

    }
}
