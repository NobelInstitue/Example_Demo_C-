﻿using System.Text;

namespace StringBuilderExampl
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //string s = "Welcome";
            //s = "Hello";
            //Console.WriteLine(s);

            //StringBuilder sb = new StringBuilder(50);
            //sb.Append("Hello Welcomeasdada");
            //sb.AppendLine("Length and capacity");
            //Console.WriteLine(sb);
            //for (int i = 0; i < sb.Length; i++)
            //    Console.Write(sb[i]); // output: Hello World!

            //StringBuilder sbAmout = new StringBuilder("Your total amount is ");
            //sbAmout.AppendFormat("{0:C} ", 25);

            //Console.WriteLine(sbAmout);//output: Your total amount is $ 25.00

            //StringBuilder sb = new StringBuilder("Hello World!");
            //sb.Insert(5, " C#");

            //Console.WriteLine(sb); //output: Hello C# World!

            //sb.Remove(5, 3);
            //Console.WriteLine(sb);

            //sb.Replace("Hello", "Hi");
            //Console.WriteLine(sb);

            //string s1 = sb.ToString();
            //Console.WriteLine(s1);

        }
    }
}
