﻿namespace Delegates
{
    internal class Program
    {
        //Single cast Delegate
        //public delegate void delmethod();

        //public class DelegateEx
        //{
        //    public static void display()
        //    {
        //        Console.WriteLine("Hello!");
        //    }

        //    public static void show()
        //    {
        //        Console.WriteLine("Hi!");
        //    }

        //    public void print()
        //    {
        //        Console.WriteLine("Print");
        //    }
        //}


        //Multicast delegate
        public delegate void delmethod(int x, int y);
        //public delegate void delmethod1();

        public class TestMultipleDelegate
        {
            public void plus_Method1(int x, int y)
            {
                Console.Write("You are in plus_Method ");
                Console.WriteLine(x + y);
            }

            public void subtract_Method2(int x, int y)
            {
                Console.Write("You are in subtract_Method ");
                Console.WriteLine(x - y);
            }
        }
        static void Main(string[] args)
        {
            // here we have assigned static method show() of class P to delegate delmethod()
            //delmethod del1 = DelegateEx.show;

            // here we have assigned static method display() of class P to delegate delmethod() using new operator
            // you can use both ways to assign the delegate
            //delmethod del2 = new delmethod(DelegateEx.display);
            // DelegateEx obj = new DelegateEx();

            //// here first we have create instance of class P and assigned the method print() to the delegate i.e. delegate with class
            //delmethod del3 = obj.print;

            // del1();
            //del2();
            /// del3();

            //DelegateEx.display();
            //Console.ReadLine();

            //Multicast delegate
            TestMultipleDelegate obj = new TestMultipleDelegate();
            delmethod del = new delmethod(obj.plus_Method1);

            // Here we have multicast
            del += new delmethod(obj.subtract_Method2);
            // plus_Method1 and subtract_Method2 are called
           // del(50, 10);
            Console.WriteLine();
            // Here again we have multicast
            del -= new delmethod(obj.plus_Method1);
            //Only subtract_Method2 is called
            del(20, 10);
            Console.ReadLine();
        }
    }
}
