﻿using System.Text;
namespace StringBuilder
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StringBuilder sr = new StringBuilder();
           
        }
    }
}
