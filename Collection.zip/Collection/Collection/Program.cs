﻿using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;

namespace Collection
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //#region List Generic
            //List<int> GenericList = new List<int>();
            //GenericList.Add(1);
            //GenericList.Add(2);
            //GenericList.Add(2);
            //GenericList.Add(5);
            //GenericList.Add(3);

            //List<int> GenericListnew = new List<int>();
            //GenericList.Add(10);
            //GenericList.Add(11);
            //GenericList.Add(12);
            //GenericList.Add(13);
            //GenericList.Add(14);

            //GenericList.AddRange(GenericListnew);

            //GenericList.Join(GenericList);

            //int[] num = { 7, 8, 9 };

            //GenericList.InsertRange(4,num);

            //GenericList.RemoveAt(4);

            //int id = GenericList.IndexOf(10);

            //int id1 = GenericList.LastIndexOf(2);

            //GenericList.Sort();

            //GenericList.Reverse();

            //int bs = GenericList.BinarySearch(7);


            // GenericList.RemoveRange(1,3);

            //int[] arr= GenericList.ToArray();

            // GenericList.AddRange(num);
            // GenericList.Clear();
            //GenericList.Remove(10);

            // GenericList.Add(10);


            //foreach (var item in GenericList)
            //{
            //    Console.WriteLine(item);

            //}
            //#endregion

            //#region Dictionary
            //Dictionary<int, string> GenericDictionary = new Dictionary<int, string>();

            //GenericDictionary.Add(1, "John");
            //GenericDictionary.Add(2, "Yash");
            //GenericDictionary.Add(4, "Komal");
            //GenericDictionary.Add(5, "rita");
            //GenericDictionary.Add(3, "Harsh");

            ////string namenew = string.Empty;
            //int a = 5;
            //bool b = GenericDictionary.TryGetValue(a, out string value);
            ////bool n=GenericDictionary.Keys.CopyTo()

            //if (GenericDictionary.TryGetValue(a, out string value2))
            //{
            //    Console.WriteLine($"The name of the student with ID {a} is {value}.");
            //}


            ////string  a = "John";

            ////GenericDictionary.TryAdd(9, "Lata");

            //foreach (KeyValuePair<int, string> item in GenericDictionary)
            //{
            //    Console.WriteLine(item.Key + " " + item.Value);
            //}

            //#endregion

            #region SortedList
            // SortedList<string, string> SortedList = new SortedList<string, string>();

            // SortedList.Add("a", "John");
            // SortedList.Add("b", "Yash");
            // SortedList.Add("x", "Komal");
            // SortedList.Add("t", "rita");
            // SortedList.Add("m", "Harsh");
            // SortedList.Add("g", "rita");
            // SortedList.Add("l", "rita");

            //// SortedList.Clear();
            // //SortedList.Values;


            // SortedList.Remove("m");
            // //string  a = "John";

            // //GenericDictionary.TryAdd(9, "Lata");

            // foreach (KeyValuePair<string, string> item in SortedList)
            // {
            //     Console.WriteLine(item.Key + " " + item.Value);
            // }
            #endregion



            //Hashtable citiesHashtable = new Hashtable(){
            //                {"UK", "London, Manchester, Birmingham"}, //Key:UK, Value:London, Manchester, Birmingham
            //                {"USA", "Chicago, New York, Washington"}, //Key:USA, Value:Chicago, New York, Washington
            //                {"India", "Mumbai, New Delhi, Pune"}      //Key:India, Value:Mumbai, New Delhi, Pune
            //            };
            //Console.WriteLine("Creating a Hashtable Using Collection-Initializer");
            //foreach (DictionaryEntry city in citiesHashtable)
            //{
            //    Console.WriteLine($"Key: {city.Key}, Value: {city.Value}");
            //}
            //Console.ReadKey();


            //Hashtable hashtable = new Hashtable();
            ////Adding elements to the Hash table using key value pair
            //hashtable.Add("EId", 1001); //Here key is Eid and value is 1001
            //hashtable.Add("Name", "James"); //Here key is Name and value is James
            //hashtable.Add("Salary", 3500); //Here key is Salary and value is 3500
            //hashtable.Add("Location", "Mumbai"); //Here key is Location and value is Mumbai
            //hashtable.Add("EmailID", "a@a.com"); //Here key is EmailID and value is a@a.com
            ////Printing the keys and their values using foreach loop
            //Console.WriteLine("Printing Hashtable using Foreach Loop");
            //foreach (object obj in hashtable.Keys)
            //{
            //    Console.WriteLine(obj + " : " + hashtable[obj]);
            //}
            ////Or
            ////foreach (DictionaryEntry de in hashtable)
            ////{
            ////    Console.WriteLine($"Key: {de.Key}, Value: {de.Value}");
            ////}
            //Console.WriteLine("\nPrinting Hashtable using Keys");
            ////I want to print the Location by using the Location key
            //Console.WriteLine("Location : " + hashtable["Location"]);
            ////I want to print the Email ID by using the EmailID key
            //Console.WriteLine("Emaild ID : " + hashtable["EmailID"]);
            //Console.ReadKey();

            #region Stack

            //Stack<int> Stacknew = new Stack<int>();
            //Stack stack=new Stack();

            //Stacknew.Push(1);
            //Stacknew.Push(2);
            //Stacknew.Push(3);
            //Stacknew.Push(4);
            //Stacknew.Push(5);   
            //Stacknew.Push(6);

            ////Stacknew.Clear();
            //Stacknew.Pop();
            //int a=Stacknew.Peek();

            ////int[] news = { 6, 7, 8 };
            ////Stacknew.CopyTo(news,3);



            //foreach (var item in Stacknew)
            //{
            //    Console.WriteLine(item);

            //}

            #endregion

            #region Queue

            Queue<string> queuenew = new Queue<string>();
            Queue que=new   Queue();
            que.Enqueue(1);
            que.Enqueue("r");
            que.Enqueue(5.5);
            ////int a = queuenew.EnsureCapacity(10);
            //queuenew.Enqueue("A");
            //queuenew.Enqueue("B");
            //queuenew.Enqueue("C");
            //queuenew.Enqueue("D");
            //queuenew.Enqueue("E");
            //queuenew.Enqueue("F");
            //queuenew.Enqueue("D");
            //queuenew.Enqueue("E");
            //queuenew.Enqueue("F");

            //queuenew.Dequeue();



            //int b = queuenew.EnsureCapacity(40);
            //queuenew.TrimExcess();


            //StringCollection strc = new StringCollection() { "q", "e", "s" };



            //string[] n = queuenew.ToArray();

            ////queuenew.

            //foreach (var item in queuenew)
            //{
            //    Console.WriteLine(item);

            //}


            #endregion

            #region Liked List

            //LinkedList<int> list = new LinkedList<int>();

            //list.AddLast(1);
            //list.AddLast(2);
            //list.AddLast(3);
            //list.AddLast(4);
            //list.AddLast(2);
            //list.AddLast(6);

            //LinkedListNode<int> s = list.Find(5);

            //LinkedListNode<int>f=list.FindLast(5);

            //LinkedListNode<int> s1 = list.Find(4);

            //foreach (var item in list)
            //{
            //    Console.WriteLine(item);

            //}


            #endregion


            #region ArrayList
            //ArrayList nonGenericarraylist = new ArrayList();
            //string str = "Like,Subscribe";
            //int x = 11;
            //DateTime d = DateTime.Parse("3-dec-1998");

            //nonGenericarraylist.Add(str);
            //nonGenericarraylist.Add(str);
            //nonGenericarraylist.Add(str);

            //List<string> lst=new List<string>();
            //lst.Add("e");
            //lst.Add("b");
            //lst.Add("h");

            //nonGenericarraylist.AddRange(lst);

            ////string[] a = new string[25];



            ////nonGenericarraylist.Insert(4, "3");
            ////nonGenericarraylist.InsertRange(5, a);

            ////nonGenericarraylist.CopyTo(a);

            //foreach (var item in nonGenericarraylist)
            //{
            //    Console.WriteLine(item);               
            //}

            #endregion

            #region HashTable
            //Hashtable ht = new Hashtable();

            //ht.Add(1, "s");
            //ht.Add(2, "r");
            //ht.Add(3, "t");
            //ht.Add(4, "u");
            //ht.Add(5, "v");
            //ht.Add(6, "v");         


            //ht.ContainsValue("d");
            //foreach (DictionaryEntry h in ht)
            //{
            //    Console.WriteLine(h.Key + " " + h.Value);
            //}

            #endregion

            #region Sorted List Non generic
            //SortedList nonGenericarraylist2 = new SortedList();
            //nonGenericarraylist2.Add("1", "Add");
            //nonGenericarraylist2.Add("2", "Clear");
            //nonGenericarraylist2.Add("6", "Remove");
            //nonGenericarraylist2.Add("4", "Insert");
            //nonGenericarraylist2.Add("5", "Insert");

            //nonGenericarraylist2.Remove("1");
            //nonGenericarraylist2.RemoveAt(0);
            //nonGenericarraylist2.Clear();
            //nonGenericarraylist2.GetKey(2);

            //foreach (DictionaryEntry item in nonGenericarraylist2)
            //{
            //    Console.WriteLine( item.Value);
            //}
            #endregion

            //StringCollection str = new StringCollection();
           // str.Add(null);
            

        }
    }
}
