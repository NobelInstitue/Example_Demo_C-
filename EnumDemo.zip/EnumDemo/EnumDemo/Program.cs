﻿namespace EnumDemo
{
    internal class Program
    {
        //enum Weekdays{
        //    Monday=9,
        //    Tuesday=7,
        //    Wednesday=6,
        //    Thursday=4,
        //    Friday=1,
        //    Saturday=2,
        //    Sunday=3
        //}
        enum Gender
        {
            Unknown,
            Male,
            Female
            
        }
        public class Employee
        {
            public string Name { get; set; }
            // 0 - Unknown
            // 1 - Male
            // 2 - Female
            public int Gender { get; set; }
        }
       
        static void Main(string[] args)
        {
            //var Weekday = Weekdays.Monday;
            //int i =(int)Weekdays.Saturday;
            //int j = (int)Weekdays.Thursday;
            //int k = (int)Weekdays.Friday;


            //switch (Weekday)
            //{
            //    case Weekdays.Monday:
            //        Console.WriteLine("This is Monday");
            //        break;
            //    case Weekdays.Tuesday:
            //        break;
            //    case Weekdays.Wednesday:
            //        break;
            //    //case Weekdays.Thursday:
            //    //    break;
            //    //case Weekdays.Friday:
            //    //    break;
            //    //case Weekdays.Saturday:
            //    //    break;
            //    //case Weekdays.Sunday:
            //    //    break;
            //    //default:
            //    //    break;
            //     }
            //Loop through Each Employees and Print the Name and Gender
            List<Employee> empList = new List<Employee>
        {
            new Employee() { Name = "Anurag", Gender = 0 },
            new Employee() { Name = "Pranaya", Gender = 1 },
            new Employee() { Name = "Priyanka", Gender = 1 },
            new Employee() { Name = "Sambit", Gender = 2 }

        };
            foreach (var emp in empList)
            {
                //To Print the Actual Gender of the Employee, 
                //we need to call the GetGender Method by passing the Integer Gender Value
                Console.WriteLine($"Name = {emp.Name} && Gender = {GetGender(emp.Gender)}");
            }
            Console.ReadLine();
            static string GetGender(int gender)
            {
                // The switch case here is now more readable and maintainable because 
                // of replacing the integral numbers with Gender Enum
                switch (gender)
                {
                    case (int)Gender.Unknown:
                        return "Unknown";
                    case (int)Gender.Male:
                        return "Male";
                    case (int)Gender.Female:
                        return "Female";
                    default:
                        return "Invalid Data for Gender";
                }
            }


        }
    }
}
