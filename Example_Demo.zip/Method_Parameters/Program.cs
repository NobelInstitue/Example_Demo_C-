﻿namespace Method_Parameters
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Program programobj=new Program();
            double lenfthofrect = 10;
            double widthofrect = 5;
            double result = programobj.CalculateAreaofRectangel(lenfthofrect, widthofrect);

            Console.WriteLine($"Area of rectabgle length of{lenfthofrect} and Width of {widthofrect} is{result}");

        }

        public double CalculateAreaofRectangel(double length,double width)
        {
            double area = length * width;
            return area;            
        }
    }
}
