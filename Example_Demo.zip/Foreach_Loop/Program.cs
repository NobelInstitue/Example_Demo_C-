﻿//int[] number1 = new int[10] { 1, 2, 3, 14, 5, 6, 7, 8, 9, 11};
//int[] number2 = new[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
//int[] number3 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];


//for (int i = 0;i< number1.Length;i++)
//{
//    Console.WriteLine(number1[i]);
//}


//string[] words = ["This", "is", "a", "foreach", "loop"];

//foreach (var item in words)
//{
    
//    //Console.Write(" ");
//    if (item == "foreach")
//    {
//        // goto labelexecute;
//        //break;
//       System.Environment.Exit(0);
//    }
//    Console.Write(item + " ");
//}
////labelexecute:
//Console.WriteLine("This is end loop");

