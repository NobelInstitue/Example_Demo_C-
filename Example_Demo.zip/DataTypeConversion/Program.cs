﻿
//int num1 = 89;
//float num2 = num1;
//Console.WriteLine(num2);

//float num = 5832.55f;
//int num2 = Convert.ToInt32(num);
//Console.WriteLine(num2);

