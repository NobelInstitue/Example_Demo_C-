﻿

#region If Else
//Console.WriteLine("Please enter number");
//int number1 =Convert.ToInt32(Console.ReadLine());

//if (number1 > 0)
//{
//    Console.WriteLine("number is positive");
//}
//else if(number1 < 0)
//{
//    Console.WriteLine("number is Negative");
//}
//else
//{
//    Console.WriteLine("number is 0");
//}
#endregion

#region Switch Statement

Console.WriteLine("Please enter day of week");
int day=Convert.ToInt32(Console.ReadLine());

//switch (day)
//{
//    case 1:        
//    case 2:        
//    case 3:         
//    case 4:        
//    case 5:
//        Console.WriteLine("Weekday");
//        break;
//   case 6: 
//   case 7:
//        Console.WriteLine("Weekend");
//        break;
//   default:
//        Console.WriteLine("invalid day");
//        break;

//}


#endregion

