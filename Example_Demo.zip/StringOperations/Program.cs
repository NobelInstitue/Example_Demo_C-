﻿
//Length
//string userstring = "This is string operation";


//int numberofchar =userstring.Length;

//if (numberofchar <20)
//{
//    Console.WriteLine("Name is less than 20 characters");
//}

//Substring

//string substringEx1 = userstring.Substring(3);

//string substringEx2 = userstring.Substring(8,6);

////int si = userstring.IndexOf("/bis");

//string substringex3 = userstring.Substring(userstring.IndexOf("string"), 8);


//Console.WriteLine(substringex3);

// indexOF

//int index = userstring.IndexOf(" ");
//Console.WriteLine(index);


//LastindexOf
//int index = userstring.LastIndexOf("n");
//Console.WriteLine(index);


//ToUpper/ToLower

//string email = "nobelsolutions@gmail.com";
//string emailMix = "NobeLSolutIons@gMaIl.Com";

//if (email.ToLower() == emailMix.ToLower())
//{
//    Console.WriteLine("Email match");
//}

//Replace string

//string outstring = userstring.Replace("operation", " Functions");
//Console.WriteLine(outstring);

//split
//string userstring = "This is  string operation";


//string[] outstring = userstring.Split(' ',StringSplitOptions.RemoveEmptyEntries);
//foreach (var item in outstring)
//{
//    Console.WriteLine(item);
//}

//Trim
//string userstring = "$$$$$    @@@ This is  string + operation @@@     $$$$$$";

//string outsring = userstring.Trim(' ','@','$');

//string outsring = userstring.TrimStart(' ', '@', '$');

//string outsring = userstring.TrimEnd(' ', '@', '$','&');
//Console.WriteLine(outsring);

//Contains

//bool outsrg = userstring.Contains(System.DateTime.Now.DayOfWeek.ToString());
//Console.WriteLine(outsrg);

//StartWith

//string link = "https://google.com";

//if (link.StartsWith("https"))
//    {
//    Console.WriteLine("This is secured link");
//}
//EndWith

//string fileex = "image.jpg";

//if (fileex.EndsWith(".jpg"))
//{
//    Console.WriteLine("This is image file");
//}

//string string1 = "This is";
//string string2 = "String Operation";

//string outstring=string1 + string2;
//string outstring1=string1.Concat(string2).ToString();
//Console.WriteLine(outstring);
//Console.WriteLine(outstring1);


string[] stringo = { "This", "is", "a", "string" };

//string.Concat(stringo);
Console.WriteLine(string.Concat(stringo));