﻿

//bool flag = default;
//Console.WriteLine(flag);

//if (flag == true)
//{
//    Console.WriteLine("This is true value");
//}
//else 
//{
//    Console.WriteLine("This is false value");
//}

//uint minpopulation = uint.MinValue;
//Console.WriteLine(minpopulation);
//uint maxpopulation = uint.MaxValue;
//Console.WriteLine(maxpopulation);

//string firstname = "Nobel";
//string lastname = "Solution";

//Console.WriteLine(firstname+lastname);

//string Message=""" 
//    this is first line
//         This is second line 
//    This is thirs line
//         This is fourth line
//    """;
//Console.WriteLine(Message);

//float a = 2589.6999f;
//Console.WriteLine(a);
//decimal b = 25666.899999m;
//double c = 78966.255666;

//Console.WriteLine("Please Enter first value");
//double a = Convert.ToDouble(Console.ReadLine());
//Console.WriteLine("Please Enter second value");
//double b = Convert.ToDouble(Console.ReadLine());
//double c = a + b;
//Console.WriteLine("final output= " + c);

//int a = 10;
//int b = a;
//a = 20;
//Console.WriteLine(b);

//string fname = "Nobel";
//string lname = fname;
//fname = "Welcome";
//Console.WriteLine(lname);


