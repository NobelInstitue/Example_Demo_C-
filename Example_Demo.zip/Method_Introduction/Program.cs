﻿using System.Net.NetworkInformation;

namespace Method_Introduction
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Program programobj=new Program();
            //programobj.printcurrentyear();

            // Program.PrintDate();
         

        }


        //public void printcurrentyear()
        //{
        //    DateTime CurrentDate= DateTime.Now;
        //    int currentyr= CurrentDate.Year;
        //    Console.WriteLine(currentyr);

        //}

        public static void PrintDate()
        {        
          DateTime date = DateTime.Now;
            Console.WriteLine(date);
           
        }
     
    }
}
