﻿



#region Arithmetics operators 

//Console.WriteLine("Please enter first number");
////int number1 = int.Parse(Console.ReadLine());
//int number1 = Convert.ToInt32(Console.ReadLine());


//Console.WriteLine("Please enter second number");
//int number2 = Convert.ToInt32(Console.ReadLine());

//int result = number1 + number2;
//Console.WriteLine(result);

//int result2 = number1 - number2;
//Console.WriteLine(result2);

//int result3 = number1 * number2;
//Console.WriteLine(result3);

//int result4 = number1 / number2;
//Console.WriteLine(result4);

//int result5 = number1 % number2;
//Console.WriteLine(result5);


//int number = 21;
////Console.WriteLine(number++);
////Console.WriteLine(++number);
////number += 1;//number=number+1

//Console.WriteLine(number--);//20
//Console.WriteLine(--number);//19


#endregion

#region Comparison Operators
//int number1 = 20;
//int number2 = 30;

////bool result = number1 == number2;
////Console.WriteLine(result);

//// result = number1 != number2;
////Console.WriteLine(result);


//bool result = number1 >= number2;
//Console.WriteLine(result);

// result = number1 <= number2;
//Console.WriteLine(result);

#endregion

#region Logical Operators && and ||

string fstring = "Nobel";
//string sString = "Solution";

//if (fstring == "Nobel" & sString == "Solution")///True  -   False=  False
//{
//    Console.WriteLine("Nobel Solution");
//}
//Console.WriteLine("No result ");


//if (fstring == "Solution" && sString == "Nobel")
//{
//    Console.WriteLine("Nobel Solution");
//}
//Console.WriteLine("No result ");
//if (fstring == "Nobel")
//{
//    Console.WriteLine("good");
//}
//else
//{
//    Console.WriteLine("bad");
//}
//int num1 = 20;
//int num2 = 30;

//string result = num1>num2 ? "good":"bad";
//Console.WriteLine(result);

#endregion

#region Null Colescing operator
////int? a = null;
//int b = a ?? -1;
//Console.WriteLine(b);

#endregion