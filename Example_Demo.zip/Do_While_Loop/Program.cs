﻿

int startingnumber = 1;
int product;
Console.WriteLine("Please enter a number");
int userinput = int.Parse(Console.ReadLine());
do
{
    product=startingnumber*userinput;
    Console.WriteLine($"{userinput} * {startingnumber}={product}");
    startingnumber += 1;
}
while(false);