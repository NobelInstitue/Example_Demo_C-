﻿

//string[] weeks = ["Monday", "Tuesday"];///size 2
//string[] weeks1 = new string[3];//size 3
//weeks1[0] = "Monday";
//weeks1[1] = "Tuesday";
//weeks1[2] = "Wendsday";

//string[] week2 = new string[] { "Monday", "Tuesday", "Wendsday" };


