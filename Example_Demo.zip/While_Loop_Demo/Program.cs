﻿
#region While Loop
//Console.WriteLine("Please input a number");

//int unserinput=int.Parse(Console.ReadLine());
//int startingnumber = 0;
//while(startingnumber<=unserinput)
//{
//    Console.WriteLine(startingnumber);
//    startingnumber=startingnumber+2;
//}
//Console.WriteLine("End of loop");
#endregion


#region Infinite Whle loop

//Console.WriteLine("Please input a number");


//int startingnumber = 0;
//while (true)
//{
//    Console.WriteLine("Please Enter a number");
//    int unserinput = int.Parse(Console.ReadLine());
//    Console.WriteLine(startingnumber);
//    startingnumber += unserinput;
//    Console.WriteLine("Total becomes"+ startingnumber);
//}

#endregion

