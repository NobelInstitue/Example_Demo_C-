﻿

//int a=10;

//Console.WriteLine(a);

//bool ischeck=true;
//Console.WriteLine(ischeck);
// ischeck = false;

//Console.WriteLine(ischeck);

//string firstname = "\"Yash\"";
//Console.WriteLine(firstname);

string path = @"C:\Users\rangn\Downloads";
Console.WriteLine(path);
int a = 3;

string fn = "5tetert";

