﻿//string firstname;

//string lastname;

//string string;
//int a;

//bool flag;

string @string;
@string = "Nobel Solutions";

Console.WriteLine(@string);
