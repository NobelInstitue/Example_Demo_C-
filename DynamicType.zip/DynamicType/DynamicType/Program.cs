﻿namespace DynamicType
{
    internal class Program
    {
        //public class Student
        //{
        //    public int Id { get; set; }
            

        //   public void DisplayStudentInfo()
        //    {
        //        Console.WriteLine(Id);
        //    }
        //}
        static void Main(string[] args)
        {
            // dynamic MyDynamicVar = "1";

            //Console.WriteLine(MyDynamicVar.GetType());

            //dynamic MyDynamicVar = 100;
            //Console.WriteLine("Value: {0}, Type: {1}", MyDynamicVar, MyDynamicVar.GetType());

            //MyDynamicVar = "Hello World!!";
            //Console.WriteLine("Value: {0}, Type: {1}", MyDynamicVar, MyDynamicVar.GetType());

            //MyDynamicVar = true;
            //Console.WriteLine("Value: {0}, Type: {1}", MyDynamicVar, MyDynamicVar.GetType());

            //MyDynamicVar = DateTime.Now;
            //Console.WriteLine("Value: {0}, Type: {1}", MyDynamicVar, MyDynamicVar.GetType());
           

            //dynamic stud = new Student();
            ////Student st = new Student();
            ////st.DisplayStudentInfo(1, "Bill");

            //stud.DisplayStudentInfo(1, "Bill");// run-time error, no compile-time error
            //stud.DisplayStudentInfo("1");// run-time error, no compile-time error
           // stud.FakeMethod();// run-time error, no compile-time error
        }
    }
}
